import {
  FaHtml5,
  FaCss3,
  FaNodeJs,
  FaReact,
  FaSass,
  FaPhoneAlt,
  FaUser,
  FaMapMarkerAlt,
  FaPaperPlane,
  FaLinkedin,
  FaGithub,
} from "react-icons/fa";
import { DiJavascript } from "react-icons/di";
import { BiLogoMongodb, BiLogoRedux, BiLogoGit } from "react-icons/bi";
import { AiFillGithub } from "react-icons/ai";
import { SiPostman, SiExpress, SiTailwindcss } from "react-icons/si";

export const navLinks = ["home", "about", "skills", "contact"];

export const socialIcons = [
  {
    icon: <FaLinkedin />,
    link: "#",
    name: "LinkedIn",
  },

  {
    icon: <FaGithub />,
    link: "#",
    name: "Github",
  },
];

export const bios = [
  {
    id: 1,
    icon: <FaUser />,
    key: "Name",
    value: "Viraj Raut",
  },
  {
    id: 2,
    icon: <FaPhoneAlt />,
    key: "Phone",
    value: "+918788978640",
  },
  {
    id: 3,
    icon: <FaPaperPlane />,
    key: "Email",
    value: "virajraut089@gmail.com",
  },
];

export const icons = [
  { icon1: <FaHtml5 />, name: "HTML" },
  { icon1: <FaCss3 style={{ marginLeft: "13px" }} />, name: "CSS-3" },
  { icon1: <SiTailwindcss />, name: "Tailwind" },
  { icon1: <DiJavascript />, name: "Javascript" },
  { icon1: <FaNodeJs />, name: "Node-js" },
  { icon1: <FaReact />, name: "React" },
  { icon1: <BiLogoRedux />, name: "Redux" },
  { icon1: <BiLogoMongodb />, name: "Mongo-Db" },
  { icon1: <SiExpress />, name: "Express-Js" },
  { icon1: <FaSass />, name: "Sass" },
  { icon1: <AiFillGithub />, name: "Github" },
  { icon1: <BiLogoGit />, name: "Git" },
  { icon1: <SiPostman />, name: "Postman" },
];

export const contacts = [
  {
    id: 1,
    icon: <FaMapMarkerAlt />,
    infoText: "Maharashtra,India",
  },
  {
    id: 2,
    icon: <FaPaperPlane />,
    infoText: "virajraut089@gmail.com",
  },
  {
    id: 3,
    icon: <FaPhoneAlt />,
    infoText: "+918788978640",
  },
];
